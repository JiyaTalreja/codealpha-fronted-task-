const audio =
    document.getElementById("audio");

const songTitle =
    document.getElementById("songTitle");

const artist =
    document.getElementById("artist");

const playButton =
    document.getElementById("playButton");

const progress =
    document.getElementById("progress");

const volume =
    document.getElementById("volume");

const currentTime =
    document.getElementById("currentTime");

const duration =
    document.getElementById("duration");


const songs = [

    {
        title: "Song One",
        artist: "Artist One",
        file: "song1.mp3"
    },

    {
        title: "Song Two",
        artist: "Artist Two",
        file: "song2.mp3"
    },

    {
        title: "Song Three",
        artist: "Artist Three",
        file: "song3.mp3"
    }

];


let currentSong = 0;


/* Load Song */

function loadSong(index) {

    currentSong = index;

    songTitle.textContent =
        songs[index].title;

    artist.textContent =
        songs[index].artist;

    audio.src =
        songs[index].file;

    progress.value = 0;

}


/* Play / Pause */

function playSong() {

    if (audio.paused) {

        audio.play();

        playButton.textContent = "⏸";

    } else {

        audio.pause();

        playButton.textContent = "▶";

    }

}


/* Next */

function nextSong() {

    currentSong++;

    if (currentSong >= songs.length) {
        currentSong = 0;
    }

    loadSong(currentSong);

    audio.play();

    playButton.textContent = "⏸";

}


/* Previous */

function previousSong() {

    currentSong--;

    if (currentSong < 0) {
        currentSong = songs.length - 1;
    }

    loadSong(currentSong);

    audio.play();

    playButton.textContent = "⏸";

}


/* Select playlist song */

function selectSong(index) {

    loadSong(index);

    audio.play();

    playButton.textContent = "⏸";

}


/* Progress bar */

audio.addEventListener(
    "timeupdate",
    function() {

        if (audio.duration) {

            progress.value =
                (audio.currentTime /
                 audio.duration) * 100;

            currentTime.textContent =
                formatTime(audio.currentTime);

            duration.textContent =
                formatTime(audio.duration);

        }

    }
);


/* Move progress */

progress.addEventListener(
    "input",
    function() {

        if (audio.duration) {

            audio.currentTime =
                (progress.value / 100)
                * audio.duration;

        }

    }
);


/* Volume */

volume.addEventListener(
    "input",
    function() {

        audio.volume =
            volume.value;

    }
);


/* When song ends */

audio.addEventListener(
    "ended",
    function() {

        nextSong();

    }
);


/* Time format */

function formatTime(seconds) {

    let minutes =
        Math.floor(seconds / 60);

    let secs =
        Math.floor(seconds % 60);

    if (secs < 10) {
        secs = "0" + secs;
    }

    return minutes + ":" + secs;

}


/* First song */

loadSong(0);