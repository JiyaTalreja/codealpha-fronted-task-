const images = [

    "https://images.unsplash.com/photo-1500534623283-312aade485b7",

    "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df",

    "https://images.unsplash.com/photo-1552053831-71594a27632d",

    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e",

    "https://images.unsplash.com/photo-1514565131-fce0801e5785",

    "https://images.unsplash.com/photo-1517849845537-4d257902454a"

];

let currentImage = 0;


function openLightbox(index) {

    currentImage = index;

    document.getElementById("lightboxImage").src =
        images[currentImage];

    document.getElementById("lightbox").style.display =
        "flex";
}


function closeLightbox() {

    document.getElementById("lightbox").style.display =
        "none";
}


function changeImage(direction) {

    currentImage = currentImage + direction;

    if (currentImage >= images.length) {
        currentImage = 0;
    }

    if (currentImage < 0) {
        currentImage = images.length - 1;
    }

    document.getElementById("lightboxImage").src =
        images[currentImage];
}


function filterImages(category) {

    const items =
        document.querySelectorAll(".gallery-item");

    items.forEach(function(item) {

        if (
            category === "all" ||
            item.dataset.category === category
        ) {

            item.style.display = "block";

        } else {

            item.style.display = "none";

        }

    });

}