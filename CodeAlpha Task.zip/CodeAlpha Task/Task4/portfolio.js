// Smooth scrolling for navigation links

const links =
    document.querySelectorAll(".nav-links a");


links.forEach(function(link) {

    link.addEventListener("click", function(event) {

        event.preventDefault();

        const target =
            document.querySelector(
                link.getAttribute("href")
            );

        target.scrollIntoView({
            behavior: "smooth"
        });

    });

});