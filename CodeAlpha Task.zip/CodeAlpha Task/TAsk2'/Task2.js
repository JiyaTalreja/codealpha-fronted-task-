const display =
    document.getElementById("display");


function appendValue(value) {

    if (display.value === "0") {

        display.value = value;

    } else {

        display.value += value;

    }

}


function clearDisplay() {

    display.value = "0";

}


function deleteLast() {

    if (display.value.length > 1) {

        display.value =
            display.value.slice(0, -1);

    } else {

        display.value = "0";

    }

}


function calculate() {

    try {

        let expression =
            display.value;

        expression =
            expression.replace(
                /(\d+(?:\.\d+)?)%/g,
                "($1/100)"
            );

        display.value =
            eval(expression);

    }

    catch {

        display.value = "Error";

    }

}


/* Keyboard Support */

document.addEventListener(
    "keydown",
    function(event) {

        const key = event.key;


        if (
            (key >= "0" && key <= "9") ||
            key === "+" ||
            key === "-" ||
            key === "*" ||
            key === "/" ||
            key === "."
        ) {

            appendValue(key);

        }


        else if (key === "Enter") {

            calculate();

        }


        else if (key === "Backspace") {

            deleteLast();

        }


        else if (key === "Escape") {

            clearDisplay();

        }

    }
);